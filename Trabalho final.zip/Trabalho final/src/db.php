<?php
require_once __DIR__ . '/../config.php';

try {
    $dsn = sprintf(
        "%s:host=%s;port=%s;dbname=%s",
        DB_DRIVER,
        DB_HOST,
        DB_PORT ?? '5432',
        DB_NAME
    );

    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false
    ]);

} catch (PDOException $e) {
    die("Erro ao conectar ao banco: " . $e->getMessage());
}
