<?php
session_start();

require_once __DIR__ . '/db.php';

/**
 * Autentica ADMIN ou SETOR
 */
function autenticar($login, $senha) {
    global $pdo;

    $sql = "SELECT * FROM usuarios WHERE login = :login LIMIT 1";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([":login" => $login]);
    $user = $stmt->fetch();

    if (!$user) {
        return false;
    }

    // Verifica senha
    if (!password_verify($senha, $user['senha'])) {
        return false;
    }

    // Salva dados da sessão
    $_SESSION['usuario']   = $user['login'];
    $_SESSION['tipo']      = $user['tipo'];     
    $_SESSION['setor_id']  = $user['id_setor'];  

    return true;
}

/**
 * Segurança do painel ADMIN
 */
function protegerAdmin() {
    if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'admin') {
        header("Location: admin.php");
        exit;
    }
}

/**
 * Protege o formulário de avaliação (somente setor)
 */
function protegerSetor() {
    if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'setor') {
        header("Location: login.php"); // página de login do formulário
        exit;
    }
}

/**
 * Logout geral
 */
function logout() {
    session_unset();
    session_destroy();
    header("Location: admin.php");
    exit;
}


