<?php
require_once '../src/auth.php'; 
require_once '../src/db.php';

// -------------------------------------------------
// LOGIN DO SETOR 
// -------------------------------------------------

// Se não existe usuário logado ou não é tipo setor → mostrar tela de login
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] !== 'setor') {

    // Tentativa de login do setor
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {

        if (autenticar($_POST['login'], $_POST['senha'])) {

            // Verifica se é setor, se for admin redireciona para painel admin
            if ($_SESSION['tipo'] !== 'setor') {
                logout(); // força sair
                $erro = "Apenas usuários de SETOR podem responder o formulário.";
            } else {
                header("Location: index.php");
                exit;
            }
        } else {
            $erro = "Usuário ou senha inválidos.";
        }
    }
    ?>

    <!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title>Login do Setor</title>
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
    <div class="container">
        <h1>Login do Setor</h1>

        <form method="POST">
            <input type="text" name="login" placeholder="Usuário do setor" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <button type="submit">Entrar</button>

            <?php if (isset($erro)) echo "<p style='color:red'>$erro</p>"; ?>
        </form>
    </div>
    </body>
    </html>

    <?php
    exit;
}

// -------------------------------------------------
// FORMULÁRIO
// -------------------------------------------------

// Enviar form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resposta'])) {

    $feedback = $_POST['feedback'] ?? null;

    foreach ($_POST['resposta'] as $id_pergunta => $nota) {
        $stmt = $pdo->prepare("
            INSERT INTO avaliacoes (id_pergunta, resposta, feedback, id_setor)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $id_pergunta,
            $nota,
            $feedback,
            $_SESSION['setor_id']  
        ]);
    }

    header("Location: obrigado.php");
    exit;
}

// Buscar perguntas ativas
$perguntas = $pdo->query("SELECT * FROM perguntas WHERE status = true ORDER BY id_pergunta")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Formulário de Avaliação</title>
    <link rel="stylesheet" href="css/style.css">
    <script defer src="js/script.js"></script>
</head>
<body>

<div class="container">
    <h1>Avaliação – Setor: <?= htmlspecialchars($_SESSION['usuario']); ?></h1>

    <form method="POST" action="">
        <?php if (empty($perguntas)): ?>
            <p><em>Nenhuma pergunta cadastrada.</em></p>

        <?php else: ?>
            <?php foreach ($perguntas as $p): ?>
                <div class="pergunta">
                    <strong><?= htmlspecialchars($p['texto']) ?></strong>

                    <div class="opcoes" data-group="<?= $p['id_pergunta'] ?>">
                        <?php
                        $cores = [
                            "#d32f2f", "#d84315", "#ef6c00", "#f57c00", "#f9a825",
                            "#fbc02d", "#cddc39", "#9ccc65", "#66bb6a", "#43a047", "#388e3c"
                        ];
                        for ($i = 0; $i <= 10; $i++): ?>
                            <label class="nota" data-value="<?= $i ?>" style="background-color: <?= $cores[$i] ?>;">
                                <input type="radio" name="resposta[<?= $p['id_pergunta'] ?>]" value="<?= $i ?>" required>
                                <?= $i ?>
                            </label>
                        <?php endfor; ?>
                    </div>
                </div>
            <?php endforeach; ?>

            <label><strong>Comentário (opcional):</strong></label><br>
            <textarea name="feedback" rows="3" placeholder="Deixe seu comentário..."></textarea><br><br>

            <button type="submit">Enviar Avaliação</button>
        <?php endif; ?>
    </form>

    <br>
    <a href="logout.php" style="color:red;">Sair do setor</a>
</div>

</body>
</html>
