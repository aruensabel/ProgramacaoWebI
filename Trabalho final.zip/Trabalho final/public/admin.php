'<?php
require_once '../src/auth.php';
require_once '../src/db.php';

// Se não estiver logado -> mostra tela de login
if (!isset($_SESSION['usuario'])) {

    // tenta logar
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
        if (autenticar($_POST['login'], $_POST['senha'])) {
            // após autenticar, só admin pode acessar este painel
            if (isset($_SESSION['tipo']) && $_SESSION['tipo'] === 'admin') {
                header("Location: admin.php?page=dashboard");
                exit;
            } else {
                // se o usuário autenticado não for admin, desloga e mostra erro
                logout();
                $erro = "Acesso restrito ao administrador.";
            }
        } else {
            $erro = "Login inválido.";
        }
    }

    // formulário de login
    ?>
    <!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title>Login Admin</title>
        <link rel="stylesheet" href="css/style.css">
        <style>
            .container { max-width:420px; margin:40px auto; padding:20px; border-radius:6px; background:#fafafa; box-shadow:0 2px 6px rgba(0,0,0,.08); }
            input { width:100%; padding:10px; margin:6px 0; box-sizing:border-box; }
            button { padding:10px 14px; background:#1976d2; color:white; border:none; border-radius:4px; cursor:pointer; }
            .erro { color: red; margin-top:10px; }
        </style>
    </head>
    <body>
    <div class="container">
        <h2>Painel Administrativo</h2>

        <form method="POST" class="login-form">
            <input type="text" name="login" placeholder="Usuário" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <button type="submit">Entrar</button>
            <?php if (isset($erro)) echo "<p class='erro'>".htmlspecialchars($erro)."</p>"; ?>
        </form>
    </div>
    </body>
    </html>
    <?php
    exit;
}

if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'admin') {
    // se session existe mas usuário não for admin, deslogar
    logout();
    exit;
}

if (($_GET['page'] ?? '') === 'logout') {
    logout();
    exit;
}

// página principal
$page = $_GET['page'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Painel Administrativo</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body { font-family: Arial, Helvetica, sans-serif; padding:20px; background:#f7f7f7; }
        .container { max-width:1100px; margin:0 auto; background:#fff; padding:20px; border-radius:6px; box-shadow:0 2px 6px rgba(0,0,0,.06); }
        .menu { margin: 15px 0; background: #f1f1f1; padding: 10px; border-radius: 6px; }
        .menu a { margin-right: 15px; font-weight: bold; text-decoration: none; color: #333; }
        .menu a:hover { text-decoration: underline; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        thead { background: #1976d2; color: white; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align:left; }
        .btn { padding: 6px 10px; background: #1976d2; color:white; border-radius:4px; text-decoration:none; display:inline-block; }
        .btn-red { background:#d32f2f; }
        .ok { color:green; font-weight:bold; }
        .erro { color:red; font-weight:bold; }
        form.inline { display:inline; }
        .small { font-size:0.9rem; color:#666; }
        select { padding:6px; }
    </style>
</head>
<body>
<div class="container">

    <h1>Painel Administrativo</h1>

    <div class="menu">
        <a href="admin.php?page=dashboard">Dashboard</a>
        <a href="admin.php?page=perguntas">Perguntas</a>
        <a href="admin.php?page=setores">Setores</a>
        <a href="admin.php?page=logout" style="color:red;">Sair</a>
    </div>

    <hr>

<?php
// =============================
// DASHBOARD 
// =============================
if ($page === 'dashboard') {

    echo "<h2>Média das Perguntas</h2>";

    // lista de setores para filtro
    $setoresList = $pdo->query("SELECT * FROM setores ORDER BY nome")->fetchAll();
    $selectedSetor = $_GET['setor'] ?? '';

    // form filtro
    echo "<form method='GET' style='margin-bottom:12px;'>
            <input type='hidden' name='page' value='dashboard'>
            <label class='small'>Filtrar por setor: </label>
            <select name='setor' onchange='this.form.submit()'>
                <option value=''>Todos os setores</option>";
    foreach ($setoresList as $s) {
        $sel = ($selectedSetor != '' && intval($selectedSetor) === intval($s['id_setor'])) ? 'selected' : '';
        echo "<option value='{$s['id_setor']}' $sel>".htmlspecialchars($s['nome'])."</option>";
    }
    echo "</select>
          </form>";

    // montar filtro SQL
    $filtro = '';
    if (!empty($selectedSetor)) {
        $idSetor = intval($selectedSetor);
        $filtro = "WHERE a.id_setor = $idSetor";
    }

    // buscar médias
    $sql = "
        SELECT p.id_pergunta, p.texto, ROUND(AVG(a.resposta), 2) AS media
        FROM perguntas p
        LEFT JOIN avaliacoes a ON a.id_pergunta = p.id_pergunta
        $filtro
        GROUP BY p.id_pergunta, p.texto
        ORDER BY p.id_pergunta
    ";

    $dados = $pdo->query($sql)->fetchAll();

    if (!$dados) {
        echo "<p><em>Nenhuma avaliação registrada.</em></p>";
    } else {
        echo "<table>
                <thead><tr><th>Pergunta</th><th style='width:140px;text-align:center;'>Média</th></tr></thead>
                <tbody>";
        foreach ($dados as $d) {
            $media = ($d['media'] === null) ? '-' : $d['media'];
            echo "<tr>
                    <td>".htmlspecialchars($d['texto'])."</td>
                    <td style='text-align:center;'>$media</td>
                  </tr>";
        }
        echo "</tbody></table>";
    }
}

// =============================
// CRUD PERGUNTAS
// =============================
if ($page === 'perguntas') {

    echo "<h2>Gerenciar Perguntas</h2>";

    // Adicionar
    if (isset($_POST['add'])) {
        $texto = trim($_POST['texto']);
        if ($texto !== '') {
            $pdo->prepare("INSERT INTO perguntas (texto, status) VALUES (?, true)")
                ->execute([$texto]);
            echo "<p class='ok'>Pergunta adicionada!</p>";
        }
    }

    // Editar
    if (isset($_POST['edit'])) {
        $pdo->prepare("UPDATE perguntas SET texto=?, status=? WHERE id_pergunta=?")
            ->execute([$_POST['texto'], $_POST['status'], $_POST['id']]);
        echo "<p class='ok'>Pergunta atualizada!</p>";
    }

    // Excluir
    if (isset($_GET['del'])) {
        $pdo->prepare("DELETE FROM perguntas WHERE id_pergunta=?")
            ->execute([$_GET['del']]);
        echo "<p class='ok'>Pergunta excluída!</p>";
    }

    // Form adicionar
    echo "<form method='POST' style='margin-bottom:12px;'>
            <input type='text' name='texto' placeholder='Nova pergunta...' required>
            <button name='add' class='btn'>Adicionar</button>
          </form>";

    // Lista
    $lista = $pdo->query("SELECT * FROM perguntas ORDER BY id_pergunta")->fetchAll();

    echo "<table>
            <thead><tr><th>ID</th><th>Pergunta</th><th>Status</th><th>Ações</th></tr></thead>
            <tbody>";

    foreach ($lista as $p) {
        $status = $p['status'] ? 'Ativa' : 'Inativa';
        echo "<tr>
                <td>{$p['id_pergunta']}</td>
                <td>".htmlspecialchars($p['texto'])."</td>
                <td>{$status}</td>
                <td>
                    <a class='btn' href='admin.php?page=perguntas&edit={$p['id_pergunta']}'>Editar</a>
                    <a class='btn btn-red' href='admin.php?page=perguntas&del={$p['id_pergunta']}' onclick=\"return confirm('Excluir pergunta?')\">Excluir</a>
                </td>
              </tr>";
    }

    echo "</tbody></table>";

    // Form edição
    if (isset($_GET['edit'])) {
        $id = intval($_GET['edit']);
        $p = $pdo->query("SELECT * FROM perguntas WHERE id_pergunta=$id")->fetch();
        if ($p) {
            echo "<h3>Editar Pergunta</h3>
                  <form method='POST'>
                    <input type='hidden' name='id' value='{$p['id_pergunta']}'>
                    <textarea name='texto' required>".htmlspecialchars($p['texto'])."</textarea><br><br>
                    <select name='status'>
                        <option value='1' ".($p['status'] ? "selected" : "").">Ativa</option>
                        <option value='0' ".(!$p['status'] ? "selected" : "").">Inativa</option>
                    </select><br><br>
                    <button name='edit' class='btn'>Salvar</button>
                  </form>";
        } else {
            echo "<p class='erro'>Pergunta não encontrada.</p>";
        }
    }
}

// =============================
// CRUD SETORES + CRIAÇÃO AUTOMÁTICA DE USUÁRIO
// =============================
if ($page === 'setores') {

    echo "<h2>Gerenciar Setores</h2>";

    // Cadastrar setor + criar usuário automaticamente
    if (isset($_POST['add'])) {

        $nomeSetor = trim($_POST['nome']);
        if ($nomeSetor !== '') {
            $login = strtolower(str_replace(' ', '', $nomeSetor));  // login = nome sem espaços
            $senha = $login;                                       // senha = login
            $hash = password_hash($senha, PASSWORD_DEFAULT);

            // 1. Criar setor
            $stmt = $pdo->prepare("INSERT INTO setores (nome) VALUES (?)");
            $stmt->execute([$nomeSetor]);

            // pega id setor
            try {
                $idSetor = $pdo->lastInsertId(); 
            } catch (Exception $e) {
                
                $idSetor = null;
            }
            if (!$idSetor) {
                // tenta obter via select com nome (último inserido)
                $res = $pdo->prepare("SELECT id_setor FROM setores WHERE nome = ? ORDER BY id_setor DESC LIMIT 1");
                $res->execute([$nomeSetor]);
                $tmp = $res->fetch();
                $idSetor = $tmp['id_setor'] ?? null;
            }

            // 2. Criar usuário vinculado 
            try {
                if ($idSetor !== null) {
                    $stmt2 = $pdo->prepare("INSERT INTO usuarios (login, senha, tipo, id_setor) VALUES (?, ?, 'setor', ?)");
                    $stmt2->execute([$login, $hash, $idSetor]);
                } else {
                    // sem id_setor
                    $stmt2 = $pdo->prepare("INSERT INTO usuarios (login, senha, tipo) VALUES (?, ?, 'setor')");
                    $stmt2->execute([$login, $hash]);
                }
            } catch (PDOException $e) {
                // tenta sem id_setor
                try {
                    $stmt2 = $pdo->prepare("INSERT INTO usuarios (login, senha, tipo) VALUES (?, ?, 'setor')");
                    $stmt2->execute([$login, $hash]);
                } catch (PDOException $e2) {
                    // não conseguiu criar usuário, mas setor já foi criado
                    echo "<p class='erro'>Setor criado, mas não foi possível criar o usuário automaticamente.</p>";
                }
            }

            echo "<p class='ok'>Setor criado!<br>Usuário: <b>".htmlspecialchars($login)."</b> | Senha: <b>".htmlspecialchars($senha)."</b></p>";
        }
    }

    // Excluir setor + excluir usuário correspondente
    if (isset($_GET['del'])) {

        $id = intval($_GET['del']);

        // Buscar setor para saber o login do usuário
        $setor = $pdo->prepare("SELECT nome FROM setores WHERE id_setor = ?");
        $setor->execute([$id]);
        $setor = $setor->fetch();

        if ($setor) {
            $login = strtolower(str_replace(' ', '', $setor['nome']));
            // tenta deletar usuário vinculado 
            $pdo->prepare("DELETE FROM usuarios WHERE login = ?")->execute([$login]);
        }

        // Remover setor
        $pdo->prepare("DELETE FROM setores WHERE id_setor = ?")->execute([$id]);

        echo "<p class='ok'>Setor removido!</p>";
    }

    // Formulário de cadastro
    echo "<form method='POST' style='margin-bottom:12px;'>
            <input type='text' name='nome' placeholder='Nome do setor...' required>
            <button name='add' class='btn'>Adicionar</button>
          </form>";

    // Listagem
    $setores = $pdo->query("SELECT * FROM setores ORDER BY id_setor")->fetchAll();

    echo "<table>
            <thead>
                <tr><th>ID</th><th>Nome</th><th>Ações</th></tr>
            </thead>
            <tbody>";

    foreach ($setores as $s) {
        echo "<tr>
                <td>{$s['id_setor']}</td>
                <td>".htmlspecialchars($s['nome'])."</td>
                <td><a class='btn btn-red' href='admin.php?page=setores&del={$s['id_setor']}' onclick=\"return confirm('Excluir setor?')\">Excluir</a></td>
              </tr>";
    }

    echo "</tbody></table>";
}
?>

</div>
</body>
</html>