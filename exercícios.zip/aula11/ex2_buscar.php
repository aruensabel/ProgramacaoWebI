<form>
<input name='nome' placeholder='Buscar por nome'>
<button>Buscar</button>
</form>
<?php
if(isset($_GET['nome'])){
    $conn = pg_connect("host=localhost dbname=teste user=postgres password=123");
    $sql="SELECT * FROM TBPESSOA WHERE PESNOME ILIKE $1";
    $res=pg_query_params($conn,$sql,["%".$_GET['nome']."%"]);
    while($r=pg_fetch_assoc($res)){
        echo $r['pesnome']."<br>";
    }
}
?>