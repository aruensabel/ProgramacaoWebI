<?php
$conn = pg_connect("host=localhost dbname=teste user=postgres password=123");
$result = pg_query($conn, "SELECT * FROM TBPESSOA");
while($r = pg_fetch_assoc($result)){
    echo $r['pesnome']." ".$r['pessobrenome']."<br>";
}
?>