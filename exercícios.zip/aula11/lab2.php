<?php
$conn = pg_connect("host=localhost dbname=teste user=postgres password=123");

$sql = "INSERT INTO TBPESSOA (PESNOME, PESSOBRENOME, PESEMAIL, PESCIDADE, PESESTADO)
        VALUES ($1,$2,$3,$4,$5)";

pg_query_params($conn, $sql, [
    $_POST['nome'], $_POST['sobrenome'], $_POST['email'], $_POST['cidade'], $_POST['estado']
]);

echo "Inserido!";
?>