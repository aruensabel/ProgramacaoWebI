<?php
// Leitura arquivo
if(file_exists("dados.txt")){
    $conteudo=file_get_contents("dados.txt");
    file_put_contents("dados2.txt", serialize($conteudo));
    echo "Gravado em dados2.txt";
} else echo "Arquivo não encontrado";
?>