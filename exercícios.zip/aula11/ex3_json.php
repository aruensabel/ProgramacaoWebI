<?php
// Gravar pessoas em JSON
$pessoa=$_POST;
$arquivo="pessoas.json";

$lista=[];

if(file_exists($arquivo)){
   $lista=json_decode(file_get_contents($arquivo),true);
}

$lista[]=$pessoa;

file_put_contents($arquivo,json_encode($lista,JSON_PRETTY_PRINT));

echo "Gravado!";
?>