<?php
// Sanitização e validação exemplo

$nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);

if(!$email){
    die("Email inválido");
}

// seguir lógica do LAB2 com dados validados
?>