<?php
// LAB 1 - Conexão simples PostgreSQL

$conn = pg_connect("host=localhost dbname=teste user=postgres password=123");

if(!$conn) die("Erro ao conectar.");

$result = pg_query($conn, "SELECT version();");

$row = pg_fetch_row($result);

echo "Conectado! Versão: ".$row[0];
?>