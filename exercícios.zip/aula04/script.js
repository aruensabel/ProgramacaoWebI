function logar(){
 let u=document.getElementById('user');
 let p=document.getElementById('pass');

 if(u.value==='user' && p.value==='pass'){
   alert('Login OK');
 }else{
   u.classList.add('user_pass_fail');
   p.classList.add('user_pass_fail');
   alert('Falhou');
 }
}
