<?php
// Exercício 1 – Generalizar e Reusar

function mediaNotas($notas) {
    return array_sum($notas)/count($notas);
}

function statusNota($media) {
    return $media > 7 ? "Aprovado" : "Reprovado";
}

function frequencia($faltas, $totalAulas) {
    $presencas = $totalAulas - count($faltas);
    return ($presencas / $totalAulas) * 100;
}

function statusFrequencia($freq) {
    return $freq > 70 ? "Aprovado" : "Reprovado";
}

// Exemplo de uso
$notas = [8,7,9];
$faltas = [1,5]; 
$totalAulas = 20;

$media = mediaNotas($notas);
$freq = frequencia($faltas, $totalAulas);

echo "Média: $media - ".statusNota($media)."\n";
echo "Frequência: $freq% - ".statusFrequencia($freq)."\n";
?>