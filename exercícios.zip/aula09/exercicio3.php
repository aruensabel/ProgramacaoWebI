<?php
// Exercício 3 – Capturar Request

function calcularValorFinal($valor, $desconto) {
    if (!is_numeric($valor) || !is_numeric($desconto)) {
        throw new Exception("Parâmetros inválidos");
    }
    return $valor - $desconto;
}

try {
    $valor = $_REQUEST['valor'] ?? null;
    $desconto = $_REQUEST['desconto'] ?? null;

    $resultado = calcularValorFinal($valor, $desconto);
    echo "Valor final: ".$resultado;

} catch (Exception $e) {
    echo "Erro: " . $e->getMessage();
}
?>