<?php
// Exercício 2 – Árvore Recursiva

$pastas = [
    "bsn" => [
        "3a Fase" => ["desenvWeb", "bancoDados1", "engSoft1"],
        "4a Fase" => ["Intro Web", "bancoDados2", "engSoft2"]
    ]
];

function montarArvore($array, $nivel = 0) {
    foreach ($array as $key => $value) {
        echo str_repeat("-", $nivel) . $key . "\n";
        if (is_array($value)) {
            montarArvore($value, $nivel + 2);
        }
    }
}

montarArvore($pastas);
?>