<?php
// Lab 3 – Classe Pessoa com Namespace + Métodos

namespace App\Model;

class Pessoa {
    private $nome;
    private $sobrenome;

    public function __construct($n, $s){
        $this->nome = $n;
        $this->sobrenome = $s;
    }

    public function getNomeCompleto(){
        return $this->nome . " " . $this->sobrenome;
    }

    public function setNome($v){ $this->nome = $v; }
    public function setSobrenome($v){ $this->sobrenome = $v; }
}
?>