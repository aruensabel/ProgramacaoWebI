<?php
// Lab 2 – Classe Pessoa (somente operações – sem métodos completos ainda)

class Pessoa {
    public $nome;
    public $sobrenome;
    public $idade;

    public function getNomeCompleto(){}
    public function falar(){}
    public function andar(){}
}
?>