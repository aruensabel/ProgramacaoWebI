<?php
// Exe 3 – Salvar cada instância em JSON

class Pessoa {
    public $nome;
    public $sobrenome;

    public function __construct($n,$s){
        $this->nome=$n; $this->sobrenome=$s;
    }

    public function toJSON(){
        return json_encode([
            "nome"=>$this->nome,
            "sobrenome"=>$this->sobrenome
        ]);
    }
}

$lista = [
    new Pessoa("Pai","Sabel"),
    new Pessoa("Mãe","Sabel"),
    new Pessoa("Aruen","Sabel")
];

$jsonList = [];

foreach($lista as $p){
    $jsonList[] = json_decode($p->toJSON(), true);
}

file_put_contents("familia.json", json_encode($jsonList, JSON_PRETTY_PRINT));

echo "Arquivo familia.json gerado!";
?>