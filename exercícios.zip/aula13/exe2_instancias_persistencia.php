<?php
// Exe 2 – Instanciar pessoas da família e salvar TXT

class Pessoa {
    public $nome;
    public $sobrenome;

    public function __construct($n,$s){
        $this->nome=$n; $this->sobrenome=$s;
    }

    public function toString(){
        return $this->nome . " " . $this->sobrenome;
    }
}

$familia = [
    new Pessoa("Pai", "Sabel"),
    new Pessoa("Mãe", "Sabel"),
    new Pessoa("Irmão", "Sabel"),
    new Pessoa("Aruen", "Sabel")
];

$conteudo = "";

foreach($familia as $p){
    $conteudo .= $p->toString() . PHP_EOL;
}

file_put_contents("familia.txt", $conteudo);

echo "Gravado em familia.txt";
?>