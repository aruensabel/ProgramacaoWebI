<?php
// Exe 1 – Classe Pessoa completa

class Pessoa {
    private $nome;
    private $sobrenome;
    private $idade;

    public function __construct($nome, $sobrenome, $idade){
        $this->nome = $nome;
        $this->sobrenome = $sobrenome;
        $this->idade = $idade;
    }

    public function getNome(){ return $this->nome; }
    public function getSobrenome(){ return $this->sobrenome; }
    public function getIdade(){ return $this->idade; }

    public function setNome($v){ $this->nome = $v; }
    public function setSobrenome($v){ $this->sobrenome = $v; }
    public function setIdade($v){ $this->idade = $v; }

    public function getNomeCompleto(){
        return $this->nome . " " . $this->sobrenome;
    }
}

$p = new Pessoa("Aruen", "Sabel", 25);
echo $p->getNomeCompleto();
?>