<?php
// Lab 1 – Função para retornar nome completo

function nomeCompleto($nome, $sobrenome){
    return $nome . " " . $sobrenome;
}

echo nomeCompleto("Aruen", "Sabel");
?>