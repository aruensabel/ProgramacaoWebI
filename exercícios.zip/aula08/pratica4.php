<?php
$SALARIO1 = 1100;
$SALARIO2 = 2001;

for ($i = 1; $i <= 100; $i++) {
    $SALARIO1++;
    if ($i == 50) break;
}

if ($SALARIO1 < $SALARIO2) {
    echo "Salário final: $SALARIO1";
}
?>