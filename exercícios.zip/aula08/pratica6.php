<?php
$alunos = [
    ["nome" => "Ana", "idade" => 20, "curso" => "ADS"],
    ["nome" => "Paulo", "idade" => 22, "curso" => "Engenharia"],
    ["nome" => "Maria", "idade" => 19, "curso" => "Direito"]
];
echo "<table border='1' cellpadding='5'><tr><th>Nome</th><th>Idade</th><th>Curso</th></tr>";
foreach ($alunos as $a) {
    echo "<tr><td>{$a['nome']}</td><td>{$a['idade']}</td><td>{$a['curso']}</td></tr>";
}
echo "</table>";
?>