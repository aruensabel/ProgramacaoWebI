<?php
define("NOME", "SeuNome");
define("SOBRENOME", "SeuSobrenome");

$NOME_COMPLETO = NOME . " " . SOBRENOME;

echo "Meu nome completo é: $NOME_COMPLETO";
?>