<?php
$disciplinas = ["Algoritmos", "Banco de Dados", "Redes", "Web 1", "POO"];
$professores = ["Carlos", "Marina", "João", "Cleber", "Fernanda"];

for ($i = 0; $i < 5; $i++) {
    echo "Disciplina {$disciplinas[$i]}, professor {$professores[$i]}.<br>";
}
?>