function calc(op){
 let a = parseFloat(document.getElementById('n1').value);
 let b = parseFloat(document.getElementById('n2').value);
 let r = 0;

 switch(op){
   case '+': r = a+b; break;
   case '-': r = a-b; break;
   case '*': r = a*b; break;
   case '/': r = a/b; break;
 }

 let campo = document.getElementById('res');
 campo.value = r;
 campo.className = '';

 if(r > 0) campo.classList.add('pos');
 else if(r < 0) campo.classList.add('neg');
 else campo.classList.add('zero');
}
