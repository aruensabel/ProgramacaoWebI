function linhaMedia(){
 let tabela = document.getElementById('notas');
 let linhas = tabela.rows.length;
 let colunas = tabela.rows[0].cells.length;

 let nova = tabela.insertRow();
 nova.insertCell().innerText = "Média";

 for(let c=1;c<colunas;c++){
   let soma = 0;
   for(let l=1;l<linhas;l++){
     soma += parseFloat(tabela.rows[l].cells[c].innerText);
   }
   nova.insertCell().innerText = (soma/(linhas-1)).toFixed(2);
 }
}

function colunaMedia(){
 let tabela = document.getElementById('notas');
 let linhas = tabela.rows.length;

 tabela.rows[0].insertCell().innerText = "Média";

 for(let l=1;l<linhas;l++){
   let soma=0;
   let qtd = tabela.rows[l].cells.length-1;
   for(let c=1;c<tabela.rows[l].cells.length;c++){
     soma += parseFloat(tabela.rows[l].cells[c].innerText);
   }
   tabela.rows[l].insertCell().innerText = (soma/qtd).toFixed(2);
 }
}
